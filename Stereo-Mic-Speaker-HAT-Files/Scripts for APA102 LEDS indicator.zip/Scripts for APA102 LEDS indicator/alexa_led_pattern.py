#!/usr/bin/env python

import numpy
import time


class AlexaLedPattern(object):
    def __init__(self, show=None, number=5):
        self.pixels_number = number
        self.pixels = [0] * 4 * number

        if not show or not callable(show):
            def dummy(data):
                pass
            show = dummy

        self.show = show
        self.stop = False

    def wakeup(self, direction=0):
        position = int((direction + 15) / (360 / self.pixels_number)) % self.pixels_number

        pixels = [0, 0, 10, 0] * self.pixels_number
        pixels[position * 4 + 2] = 20

        self.show(pixels)

    def listen(self):
        pixels = [0, 0, 10, 0] * self.pixels_number

        self.show(pixels)

    def think(self):
        pixels  = [0, 5, 5, 0, 0, 0, 10, 0] * self.pixels_number

        while not self.stop:
            self.show(pixels)
            time.sleep(0.2)
            pixels = pixels[-4:] + pixels[:-4]

    def speak(self):
        step = 1
        position = 10
        while not self.stop:
            pixels  = [0, position, 20 - position, 0] * self.pixels_number
            self.show(pixels)
            time.sleep(0.01)
            if position <= 0:
                step = 1
                time.sleep(0.4)
            elif position >= 10:
                step = -1
                time.sleep(0.4)

            position += step

    def off(self):
        self.show([0] * 4 * 15)

    def mute(self):
        pixels  = [0, 0, 0, 15] * self.pixels_number
        self.show(pixels)
